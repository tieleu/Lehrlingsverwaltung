package array_uebung;

import static org.junit.Assert.*;

import static org.hamcrest.Matchers.is;
import org.junit.Test;

public class IntArrayFunctionsTest {

	IntArrayFunctions iaf = new IntArrayFunctions();

	@Test
	public void copyTestSuccess() {
		int[] arr = new int[] { 1, 2, 3 };

		int[] copy = iaf.copy(arr);

		assertThat(copy.length, is(3));
		assertThat(copy[0], is(1));
		assertThat(copy[1], is(2));
		assertThat(copy[2], is(3));
	}

	@Test
	public void checkContentEqualsTestSuccess() {
		int[] arr = new int[] { 1, 2, 3 };
		int[] arr2 = new int[] { 1, 2, 3 };

		assertThat(iaf.checkContentEquals(arr, arr), is(true));
		assertThat(iaf.checkContentEquals(arr, arr2), is(true));
		assertThat(iaf.checkContentEquals(arr2, arr), is(true));
	}

	@Test
	public void checkContentEqualsTestNotEqual() {
		int[] arr = new int[] { 1, 2, 3, 4 };
		int[] arr2 = new int[] { 1, 2, 3 };
		int[] arr3 = new int[] { 0, 2, 3 };

		assertThat(iaf.checkContentEquals(arr, arr2), is(false));
		assertThat(iaf.checkContentEquals(arr, arr3), is(false));
		assertThat(iaf.checkContentEquals(arr2, arr3), is(false));
	}

	@Test
	public void checkExtendByOneTest() {
		int[] arr = new int[] { 1, 2, 3 };

		int[] extendedArray = iaf.extendByOne(arr);
		assertThat(extendedArray.length, is(4));
		assertThat(extendedArray[0], is(1));
		assertThat(extendedArray[1], is(2));
		assertThat(extendedArray[2], is(3));
		assertThat(extendedArray[3], is(0));
	}

	@Test
	public void checkExtendByOneAndSetTest() {
		int[] arr = new int[] { 1, 2, 3 };

		int[] extendedArray = iaf.extendByOneAndSet(arr, 30);
		assertThat(extendedArray.length, is(4));
		assertThat(extendedArray[0], is(1));
		assertThat(extendedArray[1], is(2));
		assertThat(extendedArray[2], is(3));
		assertThat(extendedArray[3], is(30));
	}

	@Test
	public void checkExtendByMultipleTest() {
		int[] arr = new int[] { 1, 22, 3 };

		int[] extendedArray = iaf.extendByMultiple(arr, 3);
		assertThat(extendedArray.length, is(6));
		assertThat(extendedArray[0], is(1));
		assertThat(extendedArray[1], is(22));
		assertThat(extendedArray[2], is(3));
		assertThat(extendedArray[3], is(0));
		assertThat(extendedArray[4], is(0));
		assertThat(extendedArray[5], is(0));
	}

	@Test
	public void checkAddValueBy1Test() {
		int[] arr = new int[] { 1, 2, 3 };

		int[] extendedArray = iaf.addValueBy1(arr);
		assertThat(extendedArray.length, is(3));
		assertThat(extendedArray[0], is(2));
		assertThat(extendedArray[1], is(3));
		assertThat(extendedArray[2], is(4));
		assertTrue(arr == extendedArray);
	}

	@Test
	public void checkAddContentByValue() {
		int[] arr = new int[] { 1, 2, 3 };

		int[] extendedArray = iaf.addContentByValue(arr, 12);
		assertThat(extendedArray.length, is(3));
		assertThat(extendedArray[0], is(13));
		assertThat(extendedArray[1], is(14));
		assertThat(extendedArray[2], is(15));
		assertTrue(arr == extendedArray);
	}

	@Test
	public void checkMultiplyContentByValue() {
		int[] arr = new int[] { 1, 2, 3 };

		int[] extendedArray = iaf.multiplyContentByValue(arr, 12);
		assertThat(extendedArray.length, is(3));
		assertThat(extendedArray[0], is(12));
		assertThat(extendedArray[1], is(24));
		assertThat(extendedArray[2], is(36));
		assertTrue(arr == extendedArray);
	}

	@Test
	public void checkMultiplyContentByValueChangeWhen12to10() {
		int[] arr = new int[] { 1, 2, 3, 4, 5, 6 };

		int[] extendedArray = iaf.multiplyContentByValueChangeWhen12to10(arr, 4);
		assertThat(extendedArray.length, is(6));
		assertThat(extendedArray[0], is(4));
		assertThat(extendedArray[1], is(8));
		assertThat(extendedArray[2], is(10));
		assertThat(extendedArray[3], is(16));
		assertThat(extendedArray[4], is(20));
		assertThat(extendedArray[5], is(24));
		assertTrue(arr == extendedArray);
	}

	@Test
	public void checkMultiplyContentByValueRemoveWhen10() {
		int[] arr = new int[] { 1, 2, 3, 4, 1, 2 };

		int[] extendedArray = iaf.multiplyContentByValueRemoveWhen10(arr, 5);
		assertThat(extendedArray.length, is(4));
		assertThat(extendedArray[0], is(5));
		assertThat(extendedArray[1], is(15));
		assertThat(extendedArray[2], is(20));
		assertThat(extendedArray[3], is(5));
	}

	@Test
	public void contentReverse() {
		int[] arr = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		int[] extendedArray = iaf.contentReverse(arr);
		assertThat(extendedArray.length, is(10));
		assertThat(extendedArray[0], is(10));
		assertThat(extendedArray[1], is(9));
		assertThat(extendedArray[2], is(8));
		assertThat(extendedArray[3], is(7));
		assertThat(extendedArray[4], is(6));
		assertThat(extendedArray[5], is(5));
		assertThat(extendedArray[6], is(4));
		assertThat(extendedArray[7], is(3));
		assertThat(extendedArray[8], is(2));
		assertThat(extendedArray[9], is(1));

		assertTrue(arr != extendedArray);
	}

	@Test
	public void contentReverseSameArray() {
		int[] arr = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 9 };

		int[] extendedArray = ((IntArrayFunctions) iaf).contentReverseSameArray(arr);
		assertThat(extendedArray.length, is(10));
		assertThat(extendedArray[0], is(9));
		assertThat(extendedArray[1], is(9));
		assertThat(extendedArray[2], is(8));
		assertThat(extendedArray[3], is(7));
		assertThat(extendedArray[4], is(6));
		assertThat(extendedArray[5], is(5));
		assertThat(extendedArray[6], is(4));
		assertThat(extendedArray[7], is(3));
		assertThat(extendedArray[8], is(2));
		assertThat(extendedArray[9], is(1));

		assertTrue(arr == extendedArray);
	}

	@Test
	public void removeEverySecondElement() {
		int[] arr = new int[] { 1, 2, 3, 4, 5, 6, 6, 7, 8 };

		int[] extendedArray = ((IntArrayFunctions) iaf).removeEverySecondElement(arr);
		assertThat(extendedArray.length, is(5));
		assertThat(extendedArray[0], is(1));
		assertThat(extendedArray[1], is(3));
		assertThat(extendedArray[2], is(5));
		assertThat(extendedArray[3], is(6));
		assertThat(extendedArray[4], is(8));

	}

	@Test
	public void removeEveryXelementTest() {
		int[] arr = { 1, 2, 3, 4, 5, 6, 7, 8 };
		int[] arr2 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

		int[] result1 = iaf.removeEveryXelement(arr, 2);
		int[] result2 = iaf.removeEveryXelement(arr2, 3);

		assertThat(result1.length, is(4));
		assertThat(result2.length, is(7));
		assertThat(result1[1], is(3));
		assertThat(result2[5], is(8));
	}

}