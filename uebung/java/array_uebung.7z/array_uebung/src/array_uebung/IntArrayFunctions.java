package array_uebung;

public class IntArrayFunctions {

  public int[] copy(int[] sourceArray) {


  }

  public boolean checkContentEquals(int[] array1, int[] array2) {

  }

  /**
   * Increase array size by 1
   * 
   * @param arr1
   * @return
   */
  public int[] extendByOne(int[] arr1) {


  }

  /**
   * Increase array size by 1 and set the value at last position
   * 
   * @param arr1
   * @param value
   * @return
   */
  public int[] extendByOneAndSet(int[] arr1, int value) {


  }

  /**
   * 
   * @param arr1
   * array provided
   * @param size
   * to increase array
   * @return
   */
  public int[] extendByMultiple(int[] arr1, int size) {


  }

  public int[] addValueBy1(int[] arr) {


  }

  public int[] addContentByValue(int[] arr, int value) {


  }

  public int[] multiplyContentByValue(int[] arr, int value) {


  }

  public int[] multiplyContentByValueChangeWhen12to10(int[] arr, int value) {


  }

  public int[] multiplyContentByValueRemoveWhen10(int[] arr, int value) {


  }

  public int[] contentReverse(int[] arr) {

  }

  public int[] contentReverseSameArray(int[] arr) {

  }

  public int[] removeEverySecondElement(int[] arr) {

  }

  public int[] removeEveryXelement(int[] arr) {

  }

}
