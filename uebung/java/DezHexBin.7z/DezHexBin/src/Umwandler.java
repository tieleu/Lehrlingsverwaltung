public class Umwandler {

  public String dezToBin(int x) {
    return "";
  }

  public String dezToHex(int x) {
    return "";
  }

  public int binToDez(String x) {

    return 0;
  }
}
