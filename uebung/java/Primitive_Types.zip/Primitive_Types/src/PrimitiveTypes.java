
public class PrimitiveTypes {

	int newZahl;
	long newBigZahl;
	boolean bool;
	char code;
	short kurz;
	byte newCode;
	float flo;
	double doub;

	public PrimitiveTypes() {

	}

	public PrimitiveTypes(int newZahl, long newBigZahl, boolean bool, char code, short kurz, byte newCode, float flo,
			double doub) {
		this.newZahl = newZahl;
		this.newBigZahl = newBigZahl;
		this.bool = bool;
		this.code = code;
		this.kurz = kurz;
		this.newCode = newCode;
		this.flo = flo;
		this.doub = doub;

	}

	public void setNewZahl(int newZahl) {
		this.newZahl = newZahl;
	}

	public int getNewZahl() {
		return newZahl;
	}

	public void setNewBigZahl(long newBigZahl) {
		this.newBigZahl = newBigZahl;
	}

	public long getNewBigZahl() {
		return newBigZahl;
	}

	public void setBool(boolean bool) {
		this.bool = bool;
	}

	public boolean getBool() {
		return bool;
	}

	public void setCode(char code) {
		this.code = code;
	}

	public char getCode() {
		return code;
	}

	public void setKurz(short kurz) {
		this.kurz = kurz;
	}

	public short getKurz() {
		return kurz;
	}

	public void setNewCode(byte newCode) {
		this.newCode = newCode;
	}

	public byte getNewCode() {
		return newCode;
	}

	public void setFlo(float flo) {
		this.flo = flo;
	}

	public float getFlo() {
		return flo;
	}

	public void setDoub(double doub) {
		this.doub = doub;
	}

	public double getDoub() {
		return doub;
	}

	public void print() {

		System.out.println("MAX VALUE");
		System.out.println("int: " + newZahl);
		System.out.println("long: " + newBigZahl);
		System.out.println("boolean: " + bool);
		System.out.println("char: " + code);
		System.out.println("short: " + kurz);
		System.out.println("byte: " + newCode);
		System.out.println("float: " + flo);
		System.out.println("double: " + doub);
	}

}
