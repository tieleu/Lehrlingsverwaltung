
public class Main {

	public static void main(String[] args) {

		PrimitiveTypes pt = new PrimitiveTypes(2147483647, 9223372036854775807l, true, (char) 220, (short) 32767,
				(byte) 127, (float) 3.4028235E38, 1.7976931348623157E308);

		pt.print();

		PrimitiveTypes pt1 = new PrimitiveTypes();
		

		pt1.setNewZahl(-2147483648);
		pt1.setNewBigZahl(-9223372036854775808l);
		pt1.setBool(false);
		pt1.setCode((char)0);
		pt1.setKurz((short) -32768);
		pt1.setNewCode((byte) -128);
	    pt1.setFlo((float)1.4E-45);
	    pt1.setDoub(4.9E-324);

		System.out.println("MIN VALUE");
		System.out.println("int: " +pt1.getNewZahl());
		System.out.println("long: " +pt1.getNewBigZahl());
		System.out.println("boolean: " +pt1.getBool());
		System.out.println("char: " +pt1.getCode());
		System.out.println("short: " +pt1.getKurz());
		System.out.println("byte: " +pt1.getNewCode());
		System.out.println("float: " +pt1.getFlo());

	}

}
