package dateFun;

import sun.java2d.pipe.SpanShapeRenderer;
import sun.util.resources.cldr.ne.CalendarData_ne_IN;
import sun.util.resources.cldr.xog.LocaleNames_xog;

import javax.swing.text.DateFormatter;
import java.net.SocketImpl;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.logging.SimpleFormatter;

public class DateFun {

    public Date toDate(String dateString) throws ParseException {
        Date date;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        date = simpleDateFormat.parse(dateString);
        return date;
    }

    public Date toDate(String dateString, SimpleDateFormat dateFormatter) throws ParseException {
        Date date = dateFormatter.parse(dateString);
        return date;
    }

    public Date toDate(LocalDate localDate) throws ParseException {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        String stringLocalDate = localDate.format(dateTimeFormatter);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
        Date date = simpleDateFormat.parse(stringLocalDate);
        return date;
    }

    public LocalDate toLocalDate(Date date) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
        String dateString = simpleDateFormat.format(date);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        LocalDate localDate = LocalDate.parse(dateString, dateTimeFormatter);
        return localDate;
    }

    public LocalDate toLocalDate(String dateString) throws ParseException {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        LocalDate localDate = LocalDate.parse(dateString, dateTimeFormatter);
        return localDate;
    }

    public LocalDateTime toLocalDateTime(Date date) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        String dateString = simpleDateFormat.format(date);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");
        LocalDateTime localDateTime = LocalDateTime.parse(dateString, dateTimeFormatter);
        return localDateTime;
    }

    public LocalDateTime toLocalDateTime(String dateString) throws ParseException {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");
        LocalDateTime localDateTime = LocalDateTime.parse(dateString, dateTimeFormatter);
        return localDateTime;
    }

    public String toString(Date date) throws ParseException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
        String dateString = simpleDateFormat.format(date);
        return dateString;
    }

    public String toString(LocalDate localDate) throws ParseException {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        String dateString = localDate.format(dateTimeFormatter);
        return dateString;
    }

    public LocalDateTime toNewYorkTime(LocalDateTime localDateTime) throws ParseException {
        localDateTime = localDateTime.minusHours(6);
        return localDateTime;
    }

    public LocalDate getLastDayOfMonth(LocalDate localDate) throws ParseException {
        int lastDay = localDate.lengthOfMonth() - localDate.getDayOfMonth();
        localDate = localDate.plusDays(lastDay);
        return localDate;
    }

    public Date getLastDayOfMonth(Date date) throws ParseException {
        LocalDate localDate = toLocalDate(date);
        int lastDay = localDate.lengthOfMonth() - localDate.getDayOfMonth();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DATE, +lastDay);
        date = calendar.getTime();
        return date;
    }
}