package dateFun;

import org.junit.Test;
import sun.util.resources.cldr.ar.CalendarData_ar_QA;
import sun.util.resources.cldr.lag.LocaleNames_lag;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.spi.CalendarNameProvider;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

public class DateFunTest {

    @Test
    public void toDateTest() throws ParseException {
        DateFun dateFun = new DateFun();
        Date date;
        Calendar calendar = Calendar.getInstance();
        calendar.set(2017, Calendar.OCTOBER, 20, 16, 45, 30);
        calendar.set(Calendar.MILLISECOND, 0);
        date = calendar.getTime();
        assertThat(dateFun.toDate("20.10.2017 16:45:30"), is(date));
    }

    @Test
    public void toDateWithSimpleDateFormatTest() throws ParseException {
        DateFun dateFun = new DateFun();
        Date date;
        Calendar calendar = Calendar.getInstance();
        calendar.set(2018, Calendar.DECEMBER, 10, 17, 00, 00);
        calendar.set(Calendar.MILLISECOND, 0);
        date = calendar.getTime();
        assertThat(dateFun.toDate("10.12.2018 17:00:00", new SimpleDateFormat("dd.MM.yyyy HH:mm:ss")), is(date));
    }

    @Test
    public void toDateWithLocalDateTest() throws ParseException {
        DateFun dateFun = new DateFun();
        LocalDate localDate = LocalDate.of(2000, Month.OCTOBER, 29);
        Date date;
        Calendar calendar = Calendar.getInstance();
        calendar.set(2000, Calendar.OCTOBER, 29, 00, 00, 00);
        calendar.set(Calendar.MILLISECOND, 0);
        date = calendar.getTime();
        assertThat(dateFun.toDate(localDate), is(date));
    }

    @Test
    public void toLocalDateTest() throws ParseException {
        DateFun dateFun = new DateFun();
        Date date;
        Calendar calendar = Calendar.getInstance();
        calendar.set(2006, Calendar.JUNE, 25, 00, 00, 00);
        calendar.set(Calendar.MILLISECOND, 0);
        date = calendar.getTime();
        assertThat(dateFun.toLocalDate(date), is(LocalDate.of(2006, Month.JUNE, 25)));
    }

    @Test
    public void toLocalDateFromStringTest() throws ParseException {
        DateFun dateFun = new DateFun();
        assertThat(dateFun.toLocalDate("25.12.2018"), is(LocalDate.of(2018, Month.DECEMBER, 25)));
    }

    @Test
    public void toLocalDateTimefromDateTest() throws ParseException {
        DateFun dateFun = new DateFun();
        Date date;
        Calendar calendar = Calendar.getInstance();
        calendar.set(2007, Calendar.APRIL, 12, 13, 15, 40);
        calendar.set(Calendar.MILLISECOND, 0);
        date = calendar.getTime();
        assertThat(dateFun.toLocalDateTime(date), is(LocalDateTime.of(2007, Month.APRIL, 12, 13, 15, 40)));
    }

    @Test
    public void toLocalDateTimefromStringTest() throws  ParseException {
        DateFun dateFun = new DateFun();
        assertThat(dateFun.toLocalDateTime("02.01.2004 20:15:00"), is(LocalDateTime.of(2004, Month.JANUARY, 2, 20, 15, 00)));
    }

    @Test
    public void  toStringfromDateTest() throws  ParseException {
        DateFun dateFun = new DateFun();
        Date date;
        Calendar calendar = Calendar.getInstance();
        calendar.set(2017, Calendar.DECEMBER, 29, 10, 00, 00);
        calendar.set(Calendar.MILLISECOND, 0);
        date = calendar.getTime();
        assertThat(dateFun.toString(date), is("29.12.2017 10:00:00"));
    }

    @Test
    public void toStringfromLocalDateTest() throws  ParseException {
        DateFun dateFun  =new DateFun();
        assertThat(dateFun.toString(LocalDate.of(2012, Month.DECEMBER, 21)), is("21.12.2012"));
    }

    @Test
    public void toNewYorkTimeTest() throws  ParseException {
        LocalDateTime localDateTime = LocalDateTime.now();
        LocalDateTime newYork= localDateTime.minusHours(6);
        DateFun dateFun = new DateFun();
        assertThat(dateFun.toNewYorkTime(localDateTime), is(newYork));
    }

    @Test
    public void getLastDayOfMonthwithLocalDateTest() throws ParseException {
        DateFun dateFun = new DateFun();
        assertThat(dateFun.getLastDayOfMonth(LocalDate.of(2018, 2, 6)), is(LocalDate.of(2018, 2, 28)));
    }

    @Test
    public void  getLastDayOfMonthwithDateTest() throws ParseException {
        DateFun dateFun = new DateFun();
        Date date;
        Calendar calendar = Calendar.getInstance();
        calendar.set(2018, Calendar.FEBRUARY, 6, 00, 00, 00);
        calendar.set(Calendar.MILLISECOND, 0);
        date = calendar.getTime();
        Date lastDayofMonth;
        Calendar cl = Calendar.getInstance();
        cl.set(2018, Calendar.FEBRUARY, 28, 00, 00, 00);
        cl.set(Calendar.MILLISECOND, 0);
        lastDayofMonth = cl.getTime();
        assertThat(dateFun.getLastDayOfMonth(date), is(lastDayofMonth));
    }
}