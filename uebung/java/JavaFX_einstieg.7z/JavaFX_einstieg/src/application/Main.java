package application;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Main extends Application {

	@Override
	public void start(Stage primaryStage) {

		primaryStage.setTitle("Hallo Welt");

		BMICalculator counter = new BMICalculator();
		counter.counter();

		try {
			VBox root = new VBox();
			HBox hbox = new HBox();

			Scene scene = new Scene(root, 400, 400);
			// scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			hbox.getChildren().addAll(counter.bmiLabel, counter.bmiResult);
			root.getChildren().addAll(counter.grosseLabel, counter.grosse, counter.gewichtLabel, counter.gewicht,
					counter.berechnen, hbox);
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {
		launch(args);
	}
}
