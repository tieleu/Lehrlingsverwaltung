package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class BMICalculator {

	Label grosseLabel = new Label("Grösse");
	Label gewichtLabel = new Label("Gewicht");
	Label bmiLabel = new Label("BMI:");
	Label bmiResult = new Label("0");

	Button berechnen = new Button("berechnen");
	Button less = new Button("less");
	
	TextField gewicht = new TextField();
	TextField grosse = new TextField();

	double gewichtM = 0.0, grosseM = 0.0, result = 0.0;

	public void counter() {

		berechnen.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {

				gewichtM = Double.parseDouble(gewicht.getText());
				System.out.println(gewichtM);
	
				grosseM = Double.parseDouble(grosse.getText());
				System.out.println(grosseM);

				result = gewichtM / (grosseM * grosseM);

				bmiResult.setText(String.valueOf(result));

			}
		});

	}

}
