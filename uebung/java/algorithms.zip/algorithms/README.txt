General Information
	Your Class has to be in a package and is not allowed to be in the default package.
	Your Class has to implement the Interface corresponding your test and the import must be exactly the package path of that Interface.
	Your Algorithm method must be the one you override from the Interface.

SingleElementFinder
	You get an int[] that contains pairs of numbers, but one number only exists once. Find the single number as fast as possible and return it.
	Array sample: [1,1,2,2,3,3,4,5,5,6,6] => number 4 exists only once!

ArraySorterTest
	Write an algorithm to sort an array with integers starting at the lowest and ending at the highest value.
	example: [1,3,2] => [1,2,3]

FindSumForNumberSorted
	You get a sorted Array and a number. You have to find out if a sum of two numbers in the array results to the number you got as parameter.
	Numbers can appear more than once in the array.

FindSumForNumberUnsorted
	Same as FindSumForNumberSorted, but the array is not sorted.

Fibonacci
	Write a RECURSIVE algorithm to calculate the fibonacci number at a given index. Indexing starts at 0.
	Fibonacci example: 0 1 1 2 3 5 8 etc.
