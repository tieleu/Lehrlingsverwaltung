package ch.tie.api.lehrlingsverwaltung.test.interfaces;

@FunctionalInterface
public interface FindSumForNumberUnsortedTestTemplate {

  public boolean elementsFoundForSum(int[] arr, int number);
}
