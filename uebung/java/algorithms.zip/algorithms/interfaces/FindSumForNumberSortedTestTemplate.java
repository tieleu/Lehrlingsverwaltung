package ch.tie.api.lehrlingsverwaltung.test.interfaces;

@FunctionalInterface
public interface FindSumForNumberSortedTestTemplate {

  public boolean elementsFoundForSum(int[] arr, int number);
}
