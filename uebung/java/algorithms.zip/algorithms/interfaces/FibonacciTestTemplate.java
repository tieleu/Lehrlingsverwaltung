package ch.tie.api.lehrlingsverwaltung.test.interfaces;

public interface FibonacciTestTemplate {

  public Long getFibonacciAtIndex(int index);
}
