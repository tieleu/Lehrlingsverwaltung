package ch.tie.api.lehrlingsverwaltung.test.interfaces;

@FunctionalInterface
public interface ArraySortTestTemplate {

  public int[] sortArray(int[] arr);
}
