package ch.tie.api.lehrlingsverwaltung.test.interfaces;

@FunctionalInterface
public interface SingleElementFinderTestTemplate {

  public int findElement(int[] arr);
}
