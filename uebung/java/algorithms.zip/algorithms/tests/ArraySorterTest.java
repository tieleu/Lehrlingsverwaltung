import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.Random;

import org.junit.Test;

public class ArraySorterTest {

  ArraySorter sorter = new ArraySorter();

  @Test
  public void testSmallArray() {
    int[] testArray = new int[]{4, 3, 2, 1};
    int[] sortedArray = sorter.sortArray(testArray);
    for (int i = 0; i < testArray.length; i++) {
      assertThat(sortedArray[i], is(equalTo(i + 1)));
    }
  }

  @Test
  public void testSmallRandomArray() {
    int[] testArray = new int[20];
    Random rand = new Random();
    for (int i = 0; i < testArray.length; i++) {
      testArray[i] = rand.nextInt();
    }
    int[] sortedArray = sorter.sortArray(testArray);
    Arrays.stream(sortedArray).reduce((prev, next) -> {
      assertTrue(prev <= next);
      return next;
    });

  }

  @Test
  public void testBigRandomArray() {
    int[] testArray = new int[200000];
    Random rand = new Random();
    for (int i = 0; i < testArray.length; i++) {
      testArray[i] = rand.nextInt();
    }
    int[] sortedArray = sorter.sortArray(testArray);
    Arrays.stream(sortedArray).reduce((prev, next) -> {
      assertTrue(prev <= next);
      return next;
    });

  }

}
