import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.*;

public class FindSumForNumberSortedTest {

  @Test
  public void testNormalArrayContainsSum() {
    int[] arr = {4, 6, 8, 10, 19};
    int number = 18;
    FindSumForNumber findSumForNumber = new FindSumForNumber();
    assertTrue(findSumForNumber.elementsFoundForSum(arr, number));
  }

  @Test
  public void testContainsSumWithZero() {
    int[] arr = {0, 4, 6, 10, 18, 19};
    int number = 18;
    FindSumForNumber findSumForNumber = new FindSumForNumber();
    assertTrue(findSumForNumber.elementsFoundForSum(arr, number));
  }

  @Test
  public void testContainsSumSameNumbers() {
    int[] arr = {4, 6, 8, 10, 19, 20, 20, 35, 50};
    int number = 40;
    FindSumForNumber findSumForNumber = new FindSumForNumber();
    assertTrue(findSumForNumber.elementsFoundForSum(arr, number));
  }

  @Test
  public void testArraySize2() {
    int[] arr = {2, 4};
    int number = 6;
    FindSumForNumber findSumForNumber = new FindSumForNumber();
    assertTrue(findSumForNumber.elementsFoundForSum(arr, number));
  }

  @Test
  public void testArraySize1() {
    int[] arr = {6};
    int number = 6;
    FindSumForNumber findSumForNumber = new FindSumForNumber();
    assertTrue(!findSumForNumber.elementsFoundForSum(arr, number));
  }

  @Test
  public void testArraySize0() {
    int[] arr = {};
    int number = 6;
    FindSumForNumber findSumForNumber = new FindSumForNumber();
    assertTrue(!findSumForNumber.elementsFoundForSum(arr, number));
  }

  @Test
  public void testArrayWithNegativeNumbers() {
    int[] arr = {-2, -1, 4, 8, 9};
    int number = 8;
    FindSumForNumber findSumForNumber = new FindSumForNumber();
    assertTrue(findSumForNumber.elementsFoundForSum(arr, number));
  }

  @Test
  public void testNormalArrayNotContainsSum() {
    int[] arr = {4, 6, 8, 10, 19};
    int number = 120;
    FindSumForNumber findSumForNumber = new FindSumForNumber();
    assertTrue(!findSumForNumber.elementsFoundForSum(arr, number));
  }

  @Test
  public void getExecutionTime() throws Exception {
    int[][] indexes = {{0, 1}, {10000, 10001}, {19998, 19999}, {5000, 14000}, {0, 19999}, {0, 1}, {10000, 10001},
        {19998, 19999}, {5000, 14000}, {0, 19999}, {0, 1}, {10000, 10001}, {19998, 19999}, {5000, 14000}, {0, 19999},
        {0, 1}, {10000, 10001}, {19998, 19999}, {5000, 14000}, {0, 19999}};
    long sum = 0;
    int searchedSum;
    for (int j = 0; j < 20; j++) {
      Random rnd = new Random(System.currentTimeMillis());
      int[] arr = new int[20000];
      for (int i = 0; i < arr.length; i++) {
        arr[i] = rnd.nextInt(200001);
      }
      searchedSum = arr[indexes[j][0]] + arr[indexes[j][1]];
      FindSumForNumber findSumForNumber = new FindSumForNumber();
      long startTime = System.nanoTime();
      assertTrue(findSumForNumber.elementsFoundForSum(arr, searchedSum));
      long endTime = System.nanoTime();
      long duration = endTime - startTime;
      sum += duration;
      System.out.println("timeTook: " + duration);
    }
    System.out.println("average time: " + (sum / 20));
    System.out.println("executions per Second: ~" + 1000000000. / (sum / 20));
  }

}