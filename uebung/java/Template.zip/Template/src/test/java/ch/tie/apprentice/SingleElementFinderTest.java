package ch.tie.apprentice;


import org.junit.Ignore;
import org.junit.Test;

import java.util.Random;

import static org.junit.Assert.assertEquals;

public class SingleElementFinderTest {

    @Test
    public void testSmallBeginning() {
        int[] arr = new int[]{0, 1, 1, 2, 2, 3, 3};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(0, result);
    }

    @Test
    public void testSmallEnd() {
        int[] arr = new int[]{1, 1, 2, 2, 3, 3, 4};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(4, result);
    }

    @Test
    public void testSmallMiddle() {
        int[] arr = new int[]{1, 1, 2, 2, 3, 4, 4, 5, 5};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(3, result);
    }

    @Test
    public void testSmallSomewhereStart() {
        int[] arr = new int[]{0, 0, 1, 2, 2, 4, 4, 6, 6};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(1, result);
    }

    @Test
    public void testSmallSomewherebigger() {
        int[] arr = new int[]{0, 0, 1, 1, 2, 2, 3, 4, 4, 6, 6};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(3, result);
    }

    @Test
    public void testSmallSomewhereEnd() {
        int[] arr = new int[]{1, 1, 2, 2, 4, 4, 5, 6, 6};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(5, result);
    }

    @Test
    public void testSmallSomewherebigger2() {
        int[] arr = new int[]{0, 0, 1, 1, 2, 3, 3, 4, 4, 6, 6};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(2, result);
    }

    @Test
    public void testBetweenDecisionOnLeftSide() {
        int[] arr = new int[]{0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(2, result);
    }

    @Test
    public void testStart() {
        int[] arr = new int[]{0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(0, result);
    }

    @Test
    public void testEnd() {
        int[] arr = new int[]{0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(8, result);
    }

    @Test
    public void testBetweenDecisioninEnd() {
        int[] arr = new int[]{0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(0, result);
    }

    @Test
    public void biggestTestEver() {
        int[] arr = new int[]{ 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16, 16};
        int result = new SingleElementFinder().findElement(arr);
        assertEquals(0, result);
    }

    @Test
    public void testBig() {
        long sum = 0;
        for (int j = 0; j < 30000; j++) {
            Random rnd = new Random();
            boolean singleElementSet = false;
            int[] arr = new int[400001];
            int singleElementVal = rnd.nextInt(200001);
            for (int i = 0; i < 400001; ) {
                int currVal = i;
                if (i == 2 * singleElementVal) {
                    arr[i++] = currVal;
                } else {
                    arr[i++] = currVal;
                    arr[i++] = currVal;
                }
            }
            long startTime = System.nanoTime();
            int result = new SingleElementFinder().findElement(arr);
            assertEquals(singleElementVal * 2, result);
            long endTime = System.nanoTime();

            long duration = (endTime - startTime);
            sum += duration;
            System.out.println("time tooks: " + duration);
        }
        System.out.println("average time: " + (sum / 30000));
        System.out.println("executions per Second: ~" + 1000000000. / (sum / 30000));
    }
}