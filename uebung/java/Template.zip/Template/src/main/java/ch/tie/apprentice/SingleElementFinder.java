package ch.tie.apprentice;

import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;

public class SingleElementFinder {

    public int findElement(int[] arr) {
        for (int i = arr.length - 1; i >= 0; ) {
            if (i == arr.length - 1) {
                if (arr[i] != arr[i - 1]) {
                    return arr[i];
                } else {
                    i /= 2;
                }
            } else {
                if (i==1) {
                    if (arr[i] == arr[i+1]) {
                        return arr[i-1];
                    }
                }
                if (i % 2 != 0) {
                    i++;
                }
                if (arr[i] != arr[i + 1] && arr[i] != arr[i - 1]) {
                    return arr[i];
                } else {
                    if (arr[i] != arr[i - 1]) {
                        for (int index = i - 2; index >= 0; index /= 2) {
                            if (index % 2 != 0) {
                                index++;
                            }
                            if (arr[i + index] != arr[(i + index) + 1] && arr[i + index] != arr[(index + i) - 1]) {
                                return arr[i+index];
                            } else {
                                if (arr[i + index] != arr[(i + index) - 1]) {
                                    i += index;
                                    index = arr.length - i;
                                }
                            }
                        }
                    } else {
                        i /= 2;

                    }
                }
            }
        }
        return 0;
//
    }
}