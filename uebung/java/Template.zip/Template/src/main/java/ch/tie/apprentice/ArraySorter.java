package ch.tie.apprentice;

public class ArraySorter {

    public int[] sortArray(int[] array) {
        int tmp = 0;
        int index = 0;
        int indexofMinValue = 0;
        int minValue = Integer.MAX_VALUE;
        for (int i = 0; i < array.length; i++) {
            minValue = Integer.MAX_VALUE;
            for (index = i; index < array.length; index++) {
                if (array[index] < minValue) {
                    minValue = array[index];
                    indexofMinValue = index;
                }
            }
            tmp = array[indexofMinValue];
            array[indexofMinValue] = array[i];
            array[i] = tmp;
        }

        return array;
    }

}

