package roomBuilder;


public class Main {

  public static void main(String[] args) {
    RoomBuilder rb = new RoomBuilder();
    rb.withBed().withComputer().withShelf().withSofa().withTable();
    Room room = rb.build();
    room.getFacility();
  }

}
