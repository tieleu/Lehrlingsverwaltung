package roomBuilder;


public class Room {
  
  private boolean table;
  private boolean bed;
  private boolean sofa;
  private boolean shelf;
  private boolean computer;
  
  public void withTable(){
    this.table = true;
  }
  
  public void withBed(){
    this.bed = true;
  }
  
  public void withSofa(){
    this.sofa = true;
  }
  
  public void withShelf(){
    this.shelf = true;
  }
  
  public void withComputer(){
    this.computer = true;
  }
  
  public String getTable(){
    return true == table ? " Table" : "";
  }
  
  public String getBed(){
    return true == bed ? " Bed" : "";
  }
  
  public String getSofa(){
    return true == sofa ? " Sofa" : "";
  }
  
  public String getShelf(){
    return true == shelf ? " Shelf" : "";
  }
  
  public String getComputer(){
    return true == computer ? " Computer" : "";
  }
  
  
  public void getFacility(){
    System.out.println("The rooms facilities are"+getTable()+getBed()+getSofa()+getShelf()+getComputer());
  }
  
}
