package roomBuilder;


public class RoomBuilder {

  Room room;

  public RoomBuilder() {
    this.room = new Room();
  }

  public RoomBuilder withTable() {
    room.withTable();
    return this;
  }

  public RoomBuilder withBed() {
    room.withBed();
    return this;
  }

  public RoomBuilder withSofa() {
    room.withSofa();
    return this;
  }

  public RoomBuilder withShelf() {
    room.withShelf();
    return this;
  }

  public RoomBuilder withComputer() {
    room.withComputer();
    return this;
  }
  
  public Room build(){
    return room;
  }

}
