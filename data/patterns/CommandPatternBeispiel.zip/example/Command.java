package example;

public interface Command {
	public void execute();
}