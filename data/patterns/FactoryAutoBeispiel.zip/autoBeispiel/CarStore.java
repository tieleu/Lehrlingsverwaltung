package autoBeispiel;


public class CarStore {

  public static void main(String[] args) {
    buyCar("porsche");
    buyCar("Audi");
  }
  
  private static void buyCar(String name){
    CarFactory c = new CarFactory();
    c.crateCar(name);
  }

}
