package autoBeispiel;


public class Porsche extends Car {
  public Porsche(String name){
    super(name);
  }
}
