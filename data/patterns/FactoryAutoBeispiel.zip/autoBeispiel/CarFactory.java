package autoBeispiel;


public class CarFactory {

  Car car;

  public Car crateCar(String name) {
    
    if (name.equals("porsche")) {
      car = new Porsche("porsche");
    } else if (name.equals("audi")) {
      car = new Audi("A3");
    }
    
    return car;
  }
}
