package autoBeispiel;


public class Audi extends Car {
  
  public Audi(String name){
    super(name);
  }
}
